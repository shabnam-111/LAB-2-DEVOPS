const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.get('/', (req, res) => {
  res.send('Hello from inside a Docker container! 🐳');
});

app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', hostname: require('os').hostname() });
});

app.listen(PORT, () => console.log(`App listening on port ${PORT}`));
